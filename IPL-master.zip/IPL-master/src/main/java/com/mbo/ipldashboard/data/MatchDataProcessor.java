
package com.mbo.ipldashboard.data;

import com.mbo.ipldashboard.model.Match;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.batch.item.ItemProcessor;

import java.time.LocalDate;

public class MatchDataProcessor implements ItemProcessor<MatchInput, Match> {

        private static final Logger log = LoggerFactory.getLogger(MatchDataProcessor.class);

        @Override
        public Match process(final MatchInput matchInput) throws Exception {
            Match match = new Match();
            match.setiD(Long.parseLong(matchInput.getiD()));
            match.setCity(matchInput.getCity());
            match.setDate(LocalDate.parse(matchInput.getDate()));
            match.setPlayerOfMatch(matchInput.getPlayerOfMatch());
            match.setVenue(matchInput.getVenue());

            String firstInning, secondInning;

            if ("bat".equals(match.getTossDecision())){
                firstInning = matchInput.getTossWinner();
                secondInning = matchInput.getTossWinner().equals(matchInput.getTeam1())
                        ? matchInput.getTeam2():matchInput.getTeam1();
            }
            else {
                secondInning = matchInput.getTossWinner();
                firstInning = matchInput.getTossWinner().equals(matchInput.getTeam1())
                        ? matchInput.getTeam2():matchInput.getTeam1();
            }

            match.setTeam1(firstInning);
            match.setTeam2(secondInning);
            match.setTossWinner(matchInput.getTossWinner());
            match.setTossDecision(matchInput.getTossDecision());
            match.setMatchWinner(matchInput.getMatchWinner());
            match.setResult(matchInput.getResult());
            match.setResultMargin(matchInput.getResultMargin());
            match.setUmpire1(matchInput.getUmpire1());
            match.setUmpire2(matchInput.getUmpire2());
            return match;
        }

    }
