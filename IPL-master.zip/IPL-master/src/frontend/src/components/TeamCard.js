import {React} from 'react';
import './TeamCard.scss';
import { Link } from 'react-router-dom';

export const TeamCard = ({teamName}) =>{
    return(
        <div className='TeamCard'>
            <h2><Link to={`teams/${teamName}`}>{teamName}</Link></h2>
        </div>
    )
}