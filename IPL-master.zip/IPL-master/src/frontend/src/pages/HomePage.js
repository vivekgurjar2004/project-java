import { React, useEffect, useState } from "react";
import './HomePage.scss';
import { TeamCard } from "../components/TeamCard";


export const HomePage = () => {

    const [home, setHome] = useState([]);
    useEffect(() => {

        const fetchMatches = async () => {
            const response = await fetch(`/team`);
            const data = await response.json();
            setHome(data);
        }
        fetchMatches();
    }, []);
    return (
        
        <div className="HomePage">
            <div className="heading-section">
            <h1>Excited Manav IPL Dashborad Home Page</h1>
            </div>
            {home.map(team => <TeamCard key={team.id} teamName={team.teamName} />)}
        </div>
    );
}
export default HomePage;