import './MatchPage.scss';
import { React, useEffect, useState } from "react";
import { MatchDetailCard } from "../components/MatchDetailCard";
import { useParams } from "react-router-dom";
import { Years } from '../components/Years';


export const MatchPage = () => {
    const [matches, setMatches] = useState();
    const { teamName, year } = useParams();
    useEffect(() => {

        const fetchMatches = async () => {
            const response = await fetch(`/team/${teamName}/matches?year=${year}`);
            const data = await response.json();
            setMatches(data);
        }
        fetchMatches();
    }, [teamName, year]);
    if (!matches) return <h1>Team Not Found</h1>;
    return (
        <div className="MatchPage">
            <div className='year-selector'>
                <h3>Select Year</h3>
                <Years teamName={teamName}></Years>
            </div>
            <div>
                <h1>{teamName} matches in {year}</h1>
                {matches.map(match => <MatchDetailCard key={match.iD} match={match} teamName={teamName}></MatchDetailCard>)}
            </div>
        </div>
    );
}

