import './TeamPage.scss';
import { PieChart } from 'react-minimal-pie-chart';
import { React, useEffect, useState } from "react";
import { MatchDetailCard } from "../components/MatchDetailCard";
import { Link, useParams } from "react-router-dom";
import { MatchSmallCard } from "../components/MatchSmallCard";


export const TeamPage = () => {

    const [team, setTeam] = useState({ matches: [] });
    const { teamName } = useParams();
    useEffect(() => {

        const fetchMatches = async () => {
            const response = await fetch(`/team/${teamName}`);
            const data = await response.json();
            setTeam(data);
        }
        fetchMatches();
    }, [teamName]);
    if (!team || !team.matches) {
        return <h1>Team Not Found</h1>;
    }
    return (
        <div className="TeamPage">
            <div className="team-name-section">
                <h1 className="team-name">{team.teamName}</h1>
            </div>
            <div className="win-loss-section">
                Win / Loss
                <PieChart
                    data={[
                        { title: 'Lost', value: team.totalMatches-team.totalWins, color: '#b43535' },
                        { title: 'Won', value: team.totalWins, color: '#46b435' },
                    ]}
                />
            </div>
            <div className="match-detail-section">
                <h1>Latest Match</h1>
                <MatchDetailCard match={team.matches[0]} teamName={team.teamName}></MatchDetailCard>
            </div>
            {team.matches.slice(1).map(match => <MatchSmallCard key={match.iD} match={match} teamName={team.teamName} />)}
            <div className='more-link'>
                <Link to={`matches/${2022}`}>
                    More>
                </Link>
            </div>
        </div>
    );
}
export default TeamPage;